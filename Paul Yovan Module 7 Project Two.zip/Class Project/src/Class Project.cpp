#include <iostream>
#include<fstream>
#include<vector>

using namespace std;

struct Course {
	string CourseNumber;
	string name; //creates our variables and vector
	vector<string> prerequisites;
};

vector<string> tokenize(string s, string del = " ") { //function seperates our string into a list of strings
	vector<string> stringArray;

	int start = 0;
	int end = s.find(del);

	while (end != -1) {
		stringArray.push_back(s.substr(start, end - start));

		start = end + del.size(); //reassigns our variables
		end = s.find(del, start);
	}

	stringArray.push_back(s.substr(start, end - start));
	return stringArray;
}

vector<Course> LoadDataStructure() {
	ifstream fin("Classes.txt", ios::in);


	vector<Course> courses; //creates our courses vector

	string line; //variable for lines in our file

	while (1) { //creates our loop for parsing
		getline(fin, line);

		if (line == "-1") {
			break;
		}

		Course course;

		vector<string> tokenizedInformation = tokenize(line, ","); //gathers information based on commas

		course.CourseNumber = tokenizedInformation[0];
		course.name = tokenizedInformation[1]; //assigns course number and course name properly

		for (int i = 2; i < tokenizedInformation.size(); ++i) { //searches for prerequisites and if there are any then they get stored properly
					course.prerequisites.push_back(tokenizedInformation[i]);
				}


		courses.push_back(course); //puts the course into our vector
	}

	fin.close(); //closes our file



	return courses;
}

void PrintCourse (Course course) {
	string CourseNumber = course.CourseNumber;
	string name = course.name; //sets our variables to the proper course information

	vector<string> prerequisites = course.prerequisites;

	cout << "Course Number: " << CourseNumber << endl;
	cout << "Course Name: " << name << endl; //prints course information
	cout << "Prerequisites: ";

	for (int i = 0; i < prerequisites.size(); ++i) {
		cout << prerequisites[i] << " "; //prints all course prerequisites if present
	}

	cout << "\n\n"; //creates a new line
}

void PrintCourseList(vector<Course> courses) {

	int k = courses.size();

	for (int i = 0; i < k - 1; ++i) {
		for (int j = 0; j < k - i - 1; ++j) {
			if (courses[j].CourseNumber > courses[j + 1].CourseNumber) {

				swap(courses[j + 1], courses[j]); //sorts our list
			}

		}
	}

	for (int i = 0; i < k; ++i) {
		PrintCourse(courses[i]); //calls our print course function
	}
}

void SearchCourse(vector<Course> courses) {
	int k = courses.size();
	string CourseNumber;
	int n = 0;

	cout << "Enter Course Number: ";
	cin >> CourseNumber;

	for (int i = 0; i < k; ++i) {
		if (courses[i].CourseNumber == CourseNumber) { //if the course is found the print the course
			n = 1;

			PrintCourse(courses[i]);
			break;
		}
	}

	if (k == 0) { //if the course is not found
		cout << "Could not find course with given course number\n";
	}
}

int main(int argc, char **argv) {
	vector<Course> courses;

	cout << "1. Load Data Structure" << endl;
	cout << "2. Print Course List" << endl;
	cout << "3. Print Course" << endl;
	cout << "9. Exit" << endl;

	int ch;

	do {
		cout << "\nEnter Your Choice: ";
		cin >> ch;
		switch(ch) {
		case 1:
			courses = LoadDataStructure();

			break;

		case 2:
			PrintCourseList(courses);

			break;

		case 3:
			SearchCourse(courses);
			break;

		case 9:
			cout << "Good Bye" << endl;
			break;

		default:
			cout << "Invalid Choice\n";
		}
	}

	while (ch != 9);
	return 0;
}


